# 和家庭分享费退订 — LSPosed 模块

把「已订业务」里 `unsubscribeFlag` 从 `"0"` 改成 `"1"`，让原本被藏起来的「退订」按钮出现。
点按钮时请求由 App 自己发出，签名/加密全部正常，和真人操作没有区别。

---

## 一、编译

### 方式 A：Android Studio（推荐）

1. Android Studio → **Open** → 选这个文件夹 `cmcc_hook`
2. 等 Gradle Sync 完成（第一次要下依赖，需要联网）
3. 菜单 **Build → Build Bundle(s) / APK(s) → Build APK(s)**
4. 产物在：

```
cmcc_hook/app/build/outputs/apk/debug/app-debug.apk
```

### 方式 B：命令行

```bash
cd cmcc_hook
./gradlew assembleDebug
```

---

## 二、如果 Sync 报错拉不到 Xposed API

`de.robv.android.xposed:api:82` 挂在 `https://api.xposed.info/`，偶尔会挂。

**手动方案：**

1. 下载 `XposedBridgeAPI-82.jar`（GitHub 搜 `XposedBridgeAPI-82.jar`，很多仓库有）
2. 放到 `cmcc_hook/app/libs/XposedBridgeAPI-82.jar`
3. 把 `app/build.gradle` 里这一行

```gradle
compileOnly 'de.robv.android.xposed:api:82'
```

改成

```gradle
compileOnly files('libs/XposedBridgeAPI-82.jar')
```

4. 重新 Sync → Build

---

## 三、安装启用

1. `adb install -r app-debug.apk`，或者把 apk 拷到手机点安装
2. 打开 **LSPosed** → 底部「模块」→ 找到「和家庭分享费退订」→ **启用**
3. 在作用域里 **只勾选「中国移动」**
4. 强制停止中国移动 App，重新打开

---

## 四、使用

1. 打开中国移动 App → 我的 → **已订业务**
2. 翻到「和家庭放心用套餐分享费」
3. **「退订」按钮应该出现了**
4. 点它 → 确认 → 那条会变成「已失效」，和家庭本体和成员都不动

看日志：LSPosed → 日志，筛 `CmccUnsub`

- `[+] patched #1 len=...` → 替换成功
- `[i] 未见可替换格式，片段：...` → 把这段片段发我，我改一行正则

---

## 五、原理备注

字段来自 `main_businessQuery.js` 的判定：

```js
r = (b || p) && ("3" === busiState || "0" === unsubscribeFlag)
```

`unsubscribeFlag === "0"` 就是不画退订按钮。这是服务端下发的，前端只负责渲染。

模块挂在四个位置，覆盖 App 可能用的所有解析路径：

| 位置 | 说明 |
|---|---|
| `okio.Buffer.readUtf8` | OkHttp 3.x 读响应体的主路径 |
| `okhttp3.ResponseBody.string()` | 同上，另一种写法 |
| `com.google.gson.Gson.fromJson` | Gson 反序列化前 |
| `org.json.JSONObject(String)` | 原生 JSON 解析 |

只要有一条命中，按钮就会出现。

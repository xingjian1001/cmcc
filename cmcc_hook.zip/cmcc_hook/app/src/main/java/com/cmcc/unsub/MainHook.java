package com.cmcc.unsub;

import android.util.Log;

import java.lang.reflect.Method;

import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;
import de.robv.android.xposed.callbacks.XC_LoadPackage;

/**
 * 目标：中国移动 App（com.greenpoint.android.mc10086.activity）
 *
 * 已订业务列表里，每条业务有一个字段 unsubscribeFlag：
 *   "0" -> 不渲染「退订」按钮
 *   "1" -> 渲染
 * 这个值来自服务端解密后的 JSON，页面在 native 层直接读。
 * 这里在「解密后的字符串」这一层做一次替换，App 自己发请求时签名/加密全部正常。
 */
public class MainHook implements IXposedHookLoadPackage {

    private static final String TAG = "CmccUnsub";
    private static final String PKG = "com.greenpoint.android.mc10086.activity";
    private static final String FIELD = "unsubscribeFlag";
    private static int hits = 0;

    @Override
    public void handleLoadPackage(XC_LoadPackage.LoadPackageParam lpparam) {
        if (!PKG.equals(lpparam.packageName)) return;

        log("loaded into " + lpparam.packageName);

        hookOkioBuffer(lpparam.classLoader);
        hookResponseBody(lpparam.classLoader);
        hookGson(lpparam.classLoader);
        hookOrgJson(lpparam.classLoader);

        log("all hooks installed, 去打开「已订业务」");
    }

    // ---------- 替换逻辑 ----------
    private static String patch(String s) {
        if (s == null || s.isEmpty() || !s.contains(FIELD)) return s;

        String out = s
                .replace("\"unsubscribeFlag\":\"0\"", "\"unsubscribeFlag\":\"1\"")
                .replace("\"unsubscribeFlag\": \"0\"", "\"unsubscribeFlag\":\"1\"")
                .replace("\"unsubscribeFlag\":0", "\"unsubscribeFlag\":\"1\"")
                .replace("\"unsubscribeFlag\":false", "\"unsubscribeFlag\":\"1\"");

        if (!out.equals(s)) {
            hits++;
            log("[+] patched #" + hits + " len=" + s.length());
        } else {
            // 见到了但没改到 —— 把附近片段打出来，方便定位真实格式
            int i = s.indexOf(FIELD);
            int from = Math.max(0, i - 120);
            int to = Math.min(s.length(), i + 160);
            log("[i] 未见可替换格式，片段：" + s.substring(from, to));
        }
        return out;
    }

    // ---------- 1) okio.Buffer ----------
    private void hookOkioBuffer(ClassLoader cl) {
        try {
            Class<?> buf = XposedHelpers.findClass("okio.Buffer", cl);

            for (Method m : buf.getDeclaredMethods()) {
                if (!m.getName().equals("readUtf8")) continue;
                if (m.getParameterTypes().length != 0) continue;
                XposedBridge.hookMethod(m, new XC_MethodHook() {
                    @Override
                    protected void afterHookedMethod(MethodHookParam p) {
                        Object r = p.getResult();
                        if (r instanceof String) {
                            String s = (String) r;
                            if (s.contains(FIELD)) p.setResult(patch(s));
                        }
                    }
                });
                log("hook okio.Buffer.readUtf8");
            }

            XposedHelpers.findAndHookMethod(buf, "readString", java.nio.charset.Charset.class,
                    new XC_MethodHook() {
                        @Override
                        protected void afterHookedMethod(MethodHookParam p) {
                            Object r = p.getResult();
                            if (r instanceof String && ((String) r).contains(FIELD)) {
                                p.setResult(patch((String) r));
                            }
                        }
                    });
            log("hook okio.Buffer.readString");
        } catch (Throwable t) {
            log("okio 失败: " + t);
        }
    }

    // ---------- 2) okhttp3.ResponseBody.string() ----------
    private void hookResponseBody(ClassLoader cl) {
        try {
            Class<?> rb = XposedHelpers.findClass("okhttp3.ResponseBody", cl);
            XposedHelpers.findAndHookMethod(rb, "string", new XC_MethodHook() {
                @Override
                protected void afterHookedMethod(MethodHookParam p) {
                    Object r = p.getResult();
                    if (r instanceof String && ((String) r).contains(FIELD)) {
                        p.setResult(patch((String) r));
                    }
                }
            });
            log("hook okhttp3.ResponseBody.string");
        } catch (Throwable t) {
            log("ResponseBody 失败: " + t);
        }
    }

    // ---------- 3) Gson ----------
    private void hookGson(ClassLoader cl) {
        try {
            Class<?> gson = XposedHelpers.findClass("com.google.gson.Gson", cl);

            XposedHelpers.findAndHookMethod(gson, "fromJson",
                    String.class, Class.class, new XC_MethodHook() {
                        @Override
                        protected void beforeHookedMethod(MethodHookParam p) {
                            if (p.args[0] instanceof String) {
                                String s = (String) p.args[0];
                                if (s.contains(FIELD)) p.args[0] = patch(s);
                            }
                        }
                    });

            XposedHelpers.findAndHookMethod(gson, "fromJson",
                    String.class, java.lang.reflect.Type.class, new XC_MethodHook() {
                        @Override
                        protected void beforeHookedMethod(MethodHookParam p) {
                            if (p.args[0] instanceof String) {
                                String s = (String) p.args[0];
                                if (s.contains(FIELD)) p.args[0] = patch(s);
                            }
                        }
                    });
            log("hook Gson.fromJson");
        } catch (Throwable t) {
            log("Gson 失败: " + t);
        }
    }

    // ---------- 4) org.json ----------
    private void hookOrgJson(ClassLoader cl) {
        try {
            Class<?> jo = XposedHelpers.findClass("org.json.JSONObject", cl);
            XposedHelpers.findAndHookMethod(jo, "<init>", String.class, new XC_MethodHook() {
                @Override
                protected void beforeHookedMethod(MethodHookParam p) {
                    if (p.args[0] instanceof String) {
                        String s = (String) p.args[0];
                        if (s.contains(FIELD)) p.args[0] = patch(s);
                    }
                }
            });
            log("hook org.json.JSONObject(String)");
        } catch (Throwable t) {
            log("org.json 失败: " + t);
        }
    }

    private static void log(String s) {
        XposedBridge.log(TAG + ": " + s);
        Log.i(TAG, s);
    }
}

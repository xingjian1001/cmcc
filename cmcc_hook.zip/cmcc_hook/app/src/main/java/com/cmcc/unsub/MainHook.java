package com.cmcc.unsub;

import android.app.AndroidAppHelper;
import android.content.Context;
import android.os.Handler;
import android.os.Looper;
import android.webkit.ValueCallback;
import android.widget.Toast;

import java.io.File;
import java.io.FileOutputStream;
import java.lang.reflect.Method;
import java.text.SimpleDateFormat;
import java.util.Date;

import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;
import de.robv.android.xposed.callbacks.XC_LoadPackage;

/**
 * v14
 *
 * v12 已证明：JS 注入通道通了（TITLE CU:no-vue 与 SCHEME cmccunsub://res/no-vue 都回来了），
 * 但 document.getElementById('app').__vue__ 一直是 undefined，120 秒都没找到 Vue 实例。
 *
 * v13 多策略找 Vue 实例：
 *   ① #app.__vue__          （Vue 2 常规）
 *   ② #app.__vue_app__      （Vue 3）
 *   ③ 遍历 DOM 找任意 __vue__
 *   ④ 遍历 window 找带 $store 的对象
 * 全失败则回传 diag-a1b0c0d0 这样的诊断串，用来判断页面到底是什么形态。
 */
public class MainHook implements IXposedHookLoadPackage {

    private static final String TAG = "CmccUnsub";
    private static final String PKG = "com.greenpoint.android.mc10086.activity";

    private static final String CODE = "111002061806";   // 和家庭分享费
    private static final String INST = "30010967558403"; // 实例 ID
    private static final String NAME = "和家庭分享费";

    private static int rounds = 0;
    private static int injected = 0;
    private static int urlSeq = 0;
    private static int jsSeq = 0;

    private static boolean x5Hooked = false;
    private static final java.util.HashSet<String> hookedClients = new java.util.HashSet<String>();
    private static final java.util.ArrayList<String> pending = new java.util.ArrayList<String>();

    /** 回传通道 B：document.title = 'CU:...' */
    private static final XC_MethodHook TITLE_HOOK = new XC_MethodHook() {
        @Override
        protected void afterHookedMethod(MethodHookParam p) {
            if (p.args == null) return;
            for (Object a : p.args) {
                if (a instanceof String && ((String) a).startsWith("CU:")) {
                    log("TITLE " + a);
                    toast("JS 回传 " + a);
                }
            }
        }
    };

    /** 回传通道 A：location.href = 'cmccunsub://res/...' */
    private static final XC_MethodHook SCHEME_HOOK = new XC_MethodHook() {
        @Override
        protected void afterHookedMethod(MethodHookParam p) {
            if (p.args == null) return;
            for (Object a : p.args) {
                if (a instanceof String && ((String) a).startsWith("cmccunsub://")) {
                    log("SCHEME " + a);
                    toast("JS 回传 " + a);
                    p.setResult(Boolean.TRUE);
                }
            }
        }
    };

    private static final String JS =
            "(function(){"
          +             "if(window.__CU15__)return;window.__CU15__=1;"
          +             "function fv(){try{var el=document.getElementById('app');"
          +             "if(el&&el.__vue__)return el.__vue__;"
          +             "if(el&&el.__vue_app__){var a=el.__vue_app__;if(a._instance)return a._instance.proxy||a._instance;return a}"
          +             "var all=document.getElementsByTagName('*');"
          +             "for(var i=0;i<all.length&&i<3000;i++){if(all[i].__vue__)return all[i].__vue__}}catch(e){}return null}"
          +             "function ui(vm){"
          +             "if(document.getElementById('cu15'))return;"
          +             "var d=document.createElement('div');d.id='cu15';"
          +             "d.setAttribute('style','position:fixed;left:0;right:0;bottom:0;z-index:99999;background:#fff;border-top:2px solid #e60012;padding:8px;font-size:13px;box-shadow:0 -2px 8px rgba(0,0,0,.2)');"
          +             "d.innerHTML='<div style=\"font-weight:bold;color:#e60012\">分享费退订（验证码）</div><div style=\"margin:6px 0\"><input id=\"cu15c\" placeholder=\"短信验证码\" maxlength=\"6\" style=\"width:110px;border:1px solid #ccc;padding:6px;font-size:14px\"><button id=\"cu15s\" style=\"margin-left:6px;padding:6px 10px\">获取验证码</button><button id=\"cu15g\" style=\"margin-left:6px;padding:6px 10px;background:#e60012;color:#fff;border:0\">提交退订</button></div><div id=\"cu15r\" style=\"color:#666;word-break:break-all\">就绪</div>';"
          +             "document.body.appendChild(d);"
          +             "function say(x){var e=document.getElementById('cu15r');if(e)e.textContent=x;try{document.title='CU:'+x}catch(err){}}"
          +             "document.getElementById('cu15s').onclick=function(){"
          +             "say('发送中...');"
          +             "var b={businessName:'和家庭分享费',productCode:'111002061806',productId:'111002061806',instanceId:'30010967558403',busiReturnEffTime:'1'};"
          +             "try{vm.$store.dispatch('businessQuery/getSmsCode',{business:b,effectiveTimeType:'1'}).then(function(r){say('发码:'+JSON.stringify(r).slice(0,160))})['catch'](function(e){say('发码异常:'+e)})}catch(e){say('发码失败:'+e)}};"
          +             "document.getElementById('cu15g').onclick=function(){"
          +             "var c=document.getElementById('cu15c').value;if(!c){say('请先输入验证码');return}"
          +             "say('提交中...');"
          +             "var q={businessName:'和家庭分享费',productType:'01',productId:'111002061806',spid:'',bizCode:'',smsCode:c,busiReturnEffTime:'1',instanceId:'30010967558403'};"
          +             "try{vm.$store.dispatch('businessQuery/getUnifyCancel',q).then(function(r){say('结果:'+JSON.stringify(r).slice(0,240))})['catch'](function(e){say('异常:'+e)})}catch(e){say('失败:'+e)}};"
          +             "var b={businessName:'和家庭分享费',productCode:'111002061806',instanceId:'30010967558403',busiReturnEffTime:'1'};"
          +             "try{vm.$store.dispatch('businessQuery/getSmsCode',{business:b,effectiveTimeType:'1'}).then(function(r){say('验证码已请求 '+JSON.stringify(r).slice(0,120))})['catch'](function(e){say('就绪(发码失败)')})}catch(e){say('就绪')}"
          +             "}"
          +             "var n=0,t=setInterval(function(){n++;var vm=fv();"
          +             "if(!vm&&n%5===0&&n>10){try{for(var k in window){var v=window[k];if(v&&v.$store&&v.$store.state){vm=v;break}}}catch(e){}}"
          +             "if(!vm)return;var st=vm.$store&&vm.$store.state;"
          +             "if(!st||!vm.$store.dispatch)return;"
          +             "clearInterval(t);"
          +             "try{if(st.remoteState){var p=(st.userInfo&&st.userInfo.loginProvince)||'100';"
          +             "st.remoteState.CMCC_BusinessQuery_ContractUnsubscribe_Scenario=JSON.stringify({zero_penalty_provinces:[p],phone_payment_provinces:[p],cash_payment_provinces:[p]});}}catch(e){}"
          +             "ui(vm);},500);"
          +             "})()";

    @Override
    public void handleLoadPackage(XC_LoadPackage.LoadPackageParam lpparam) {
        if (!PKG.equals(lpparam.packageName)) return;

        log("=== loaded v15 pkg=" + lpparam.packageName + " process=" + lpparam.processName);

        hookOkioBuffer(lpparam.classLoader);
        hookResponseBody(lpparam.classLoader);
        hookGson(lpparam.classLoader);
        hookOrgJson(lpparam.classLoader);
        hookWebViewNative(lpparam.classLoader);
        startX5Watcher(lpparam.classLoader);
        hookAppCreate(lpparam.classLoader);

        toast("CmccUnsub v15 已注入");
    }

    // ---------------- 日志 ----------------

    private static File logFile() {
        try {
            Context c = AndroidAppHelper.currentApplication();
            if (c == null) return null;
            return new File(c.getFilesDir(), "cmcc_log.txt");
        } catch (Throwable t) {
            return null;
        }
    }

    private static void log(String msg) {
        String line = new SimpleDateFormat("HH:mm:ss").format(new Date()) + "  " + msg;
        XposedBridge.log(TAG + ": " + msg);
        try {
            File f = logFile();
            if (f == null) {
                synchronized (pending) {
                    if (pending.size() < 300) pending.add(line);
                }
                return;
            }
            if (f.length() > 300000) f.delete();
            FileOutputStream fo = new FileOutputStream(f, true);
            synchronized (pending) {
                for (String p : pending) fo.write((p + "\n").getBytes("UTF-8"));
                pending.clear();
            }
            fo.write((line + "\n").getBytes("UTF-8"));
            fo.close();
        } catch (Throwable ignored) {
        }
    }

    private void hookAppCreate(ClassLoader cl) {
        try {
            XposedHelpers.findAndHookMethod("android.app.Application", cl, "onCreate",
                    new XC_MethodHook() {
                        @Override
                        protected void afterHookedMethod(MethodHookParam p) {
                            log("Application.onCreate —— 日志开始落盘");
                        }
                    });
        } catch (Throwable t) {
            XposedBridge.log(TAG + ": appcreate fail " + t);
        }
    }

    // ---------------- WebView ----------------

    private void hookWebViewNative(ClassLoader cl) {
        try {
            Class<?> wv = XposedHelpers.findClass("android.webkit.WebView", cl);
            XposedBridge.hookAllMethods(wv, "loadUrl", new PageHook("native"));
            XposedBridge.hookAllMethods(wv, "evaluateJavascript", new EvalHook("native"));
            log("hook android.webkit.WebView OK");
        } catch (Throwable t) {
            log("hook android.webkit.WebView FAIL " + t);
        }
    }

    private void startX5Watcher(final ClassLoader cl) {
        Thread th = new Thread(new Runnable() {
            @Override
            public void run() {
                for (int i = 0; i < 240; i++) {
                    try {
                        Class<?> c = Class.forName("com.tencent.smtt.sdk.WebView", false, cl);
                        hookX5(c);
                        return;
                    } catch (Throwable ignored) {
                    }
                    try {
                        Thread.sleep(500);
                    } catch (Throwable ignored) {
                    }
                }
                log("X5 类 2 分钟内没出现");
            }
        });
        th.setDaemon(true);
        th.start();
    }

    private void hookX5(Class<?> c) {
        if (x5Hooked) return;
        x5Hooked = true;
        log("X5 类已加载: " + c.getName());

        try {
            XposedBridge.hookAllMethods(c, "loadUrl", new PageHook("x5"));
            XposedBridge.hookAllMethods(c, "evaluateJavascript", new EvalHook("x5"));
            log("hook X5 WebView OK");
            toast("X5 已挂钩");
        } catch (Throwable t) {
            log("hook X5 FAIL " + t);
        }

        try {
            Class<?> wc = Class.forName("com.tencent.smtt.sdk.WebViewClient", false, c.getClassLoader());
            XposedBridge.hookAllMethods(wc, "onPageFinished", new XC_MethodHook() {
                @Override
                protected void afterHookedMethod(MethodHookParam p) {
                    if (p.args == null || p.args.length < 2) return;
                    final Object w = p.args[0];
                    String url = String.valueOf(p.args[1]);
                    if (!url.contains("businessQuery")) return;
                    log("X5 onPageFinished " + cut(url));
                    if (w == null) return;
                    for (int i = 1; i <= 6; i++) {
                        new Handler(Looper.getMainLooper()).postDelayed(new Runnable() {
                            @Override
                            public void run() {
                                evalJs(w, JS, "onPageFinished");
                            }
                        }, 600L * i);
                    }
                }
            });
            XposedBridge.hookAllMethods(wc, "shouldOverrideUrlLoading", SCHEME_HOOK);

            XposedBridge.hookAllMethods(c, "setWebViewClient", new XC_MethodHook() {
                @Override
                protected void afterHookedMethod(MethodHookParam p) {
                    if (p.args == null || p.args.length < 1) return;
                    Object client = p.args[0];
                    if (client == null) return;
                    Class<?> cc = client.getClass();
                    if (!hookedClients.add(cc.getName())) return;
                    log("hook client " + cc.getName());
                    XposedBridge.hookAllMethods(cc, "shouldOverrideUrlLoading", SCHEME_HOOK);
                }
            });

            XposedBridge.hookAllMethods(c, "setWebChromeClient", new XC_MethodHook() {
                @Override
                protected void afterHookedMethod(MethodHookParam p) {
                    if (p.args == null || p.args.length < 1) return;
                    Object cc = p.args[0];
                    if (cc == null) return;
                    String n = cc.getClass().getName();
                    if (!hookedClients.add("chrome:" + n)) return;
                    log("hook chrome " + n);
                    XposedBridge.hookAllMethods(cc.getClass(), "onReceivedTitle", TITLE_HOOK);
                }
            });
            log("hook X5 WebViewClient OK");
        } catch (Throwable t) {
            log("hook X5 WebViewClient FAIL " + t);
        }
    }

    private class PageHook extends XC_MethodHook {
        private final String tag;

        PageHook(String tag) {
            this.tag = tag;
        }

        @Override
        protected void afterHookedMethod(MethodHookParam p) {
            final Object w = p.thisObject;
            if (w == null) return;
            String u = "";
            if (p.args != null && p.args.length > 0 && p.args[0] instanceof String) {
                u = (String) p.args[0];
            }
            if (u.startsWith("javascript:")) return;
            if (urlSeq < 60) {
                urlSeq++;
                log("loadUrl[" + tag + "] " + w.getClass().getName() + " -> " + cut(u));
            }
            if (!u.contains("businessQuery")) return;
            for (int i = 1; i <= 8; i++) {
                new Handler(Looper.getMainLooper()).postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        evalJs(w, JS, "loadUrl");
                    }
                }, 1500L * i);
            }
        }
    }

    private class EvalHook extends XC_MethodHook {
        private final String tag;

        EvalHook(String tag) {
            this.tag = tag;
        }

        @Override
        protected void beforeHookedMethod(MethodHookParam p) {
            if (p.args == null || p.args.length < 1) return;
            if (!(p.args[0] instanceof String)) return;
            String s = (String) p.args[0];
            if (jsSeq < 20) {
                jsSeq++;
                log("evaluateJavascript[" + tag + "] " + cut(s));
            }
            if (s.contains("__CU10__")) return;
            p.args[0] = s + ";" + JS;
        }
    }

    /**
     * 调 WebView.evaluateJavascript。X5 的回调类型是
     * com.tencent.smtt.sdk.ValueCallback，不是 android.webkit.ValueCallback。
     */
    private static void evalJs(Object w, String js, String why) {
        if (w == null) return;
        ClassLoader cl = w.getClass().getClassLoader();
        try {
            Class<?> cbCls = Class.forName("com.tencent.smtt.sdk.ValueCallback", false, cl);
            Method m = w.getClass().getMethod("evaluateJavascript", String.class, cbCls);
            m.invoke(w, js, null);
            log("inject ok (" + why + ") via smtt.evaluateJavascript");
            return;
        } catch (Throwable t) {
            log("inject smtt fail (" + why + ") " + t.getClass().getSimpleName());
        }
        try {
            Method m = w.getClass().getMethod("evaluateJavascript", String.class, ValueCallback.class);
            m.invoke(w, js, null);
            log("inject ok (" + why + ") via webkit.evaluateJavascript");
            return;
        } catch (Throwable t) {
            log("inject webkit fail (" + why + ") " + t.getClass().getSimpleName());
        }
        try {
            Method m = w.getClass().getMethod("loadUrl", String.class);
            m.invoke(w, "javascript:" + js);
            log("inject fallback (" + why + ") via loadUrl javascript:");
        } catch (Throwable t2) {
            log("inject FAIL (" + why + ") " + t2);
        }
    }

    private static String cut(String s) {
        if (s == null) return "null";
        s = s.replace("\n", " ");
        return s.length() > 150 ? s.substring(0, 150) + "..." : s;
    }

    // ---------------- JSON 改写 ----------------

    private static String patch(String s) {
        if (s == null || s.isEmpty()) return s;
        if (!s.contains("cancelFlag")) return s;

        String out = s;

        if (out.contains(CODE)) {
            String t = injectContract(out);
            if (t != null && !t.equals(out)) {
                out = t;
                injected++;
                log("contract injected #" + injected);
                toast("已注入合约退订 #" + injected);
            }
        }

        String out2 = out.replace("\"cancelFlag\":\"1\"", "\"cancelFlag\":\"0\"");
        if (!out2.equals(out)) {
            rounds++;
            log("cancelFlag opened #" + rounds);
        }
        return out2;
    }

    private static String injectContract(String s) {
        int k = s.indexOf("\"productCode\":\"" + CODE + "\"");
        if (k < 0) return s;

        int start = s.lastIndexOf('{', k);
        int end = s.indexOf('}', k);
        if (start < 0 || end < k) return s;

        String seg = s.substring(start, end + 1);
        if (seg.contains("\"contractId\"")) return s;

        String ns = seg;

        if (ns.contains("\"contractFlag\":\"1\"")) {
            ns = ns.replace("\"contractFlag\":\"1\"", "\"contractFlag\":\"0\"");
        } else if (!ns.contains("\"contractFlag\"")) {
            ns = ns.substring(0, ns.length() - 1) + ",\"contractFlag\":\"0\"}";
        }

        ns = ns.replace("\"majorType\":\"1\",", "\"majorType\":\"\",");
        ns = ns.replace("\"majorType\":\"1\"}", "\"majorType\":\"\"}");
        ns = ns.replace("\"cancelFlag\":\"1\"", "\"cancelFlag\":\"0\"");
        ns = ns.replace("\"busiState\":\"3\"", "\"busiState\":\"4\"");

        if (ns.contains("\"cancelState\"")) {
            ns = ns.replace("\"cancelState\":\"1\"", "\"cancelState\":\"0\"");
        } else {
            ns = ns.substring(0, ns.length() - 1) + ",\"cancelState\":\"0\"}";
        }

        String contract = ",\"contractList\":{\"contractDetailsList\":[{"
                + "\"contractName\":\"" + NAME + "\","
                + "\"contractId\":\"" + CODE + "\","
                + "\"contractInstanceId\":\"" + INST + "\","
                + "\"cancelFlag\":\"0\","
                + "\"cancelState\":\"0\","
                + "\"contractReturnEffTime\":\"0\"}]}";

        ns = ns.substring(0, ns.length() - 1) + contract + "}";

        return s.substring(0, start) + ns + s.substring(end + 1);
    }

    private static void toast(final String msg) {
        try {
            new Handler(Looper.getMainLooper()).post(new Runnable() {
                @Override
                public void run() {
                    try {
                        Context ctx = AndroidAppHelper.currentApplication();
                        if (ctx != null) Toast.makeText(ctx, msg, Toast.LENGTH_SHORT).show();
                    } catch (Throwable ignored) {
                    }
                }
            });
        } catch (Throwable ignored) {
        }
    }

    // ---------------- 网络层 ----------------

    private void hookOkioBuffer(ClassLoader cl) {
        try {
            Class<?> buf = XposedHelpers.findClass("okio.Buffer", cl);
            int n = 0;
            for (Method m : buf.getDeclaredMethods()) {
                if (!m.getName().equals("readUtf8") || m.getParameterTypes().length != 0) continue;
                XposedBridge.hookMethod(m, new XC_MethodHook() {
                    @Override
                    protected void afterHookedMethod(MethodHookParam p) {
                        Object r = p.getResult();
                        if (r instanceof String) p.setResult(patch((String) r));
                    }
                });
                n++;
            }
            XposedHelpers.findAndHookMethod(buf, "readString", java.nio.charset.Charset.class,
                    new XC_MethodHook() {
                        @Override
                        protected void afterHookedMethod(MethodHookParam p) {
                            Object r = p.getResult();
                            if (r instanceof String) p.setResult(patch((String) r));
                        }
                    });
            log("hook okio.Buffer readUtf8 x" + n);
        } catch (Throwable t) {
            log("hook okio FAIL " + t);
        }
    }

    private void hookResponseBody(ClassLoader cl) {
        try {
            Class<?> rb = XposedHelpers.findClass("okhttp3.ResponseBody", cl);
            XposedHelpers.findAndHookMethod(rb, "string", new XC_MethodHook() {
                @Override
                protected void afterHookedMethod(MethodHookParam p) {
                    Object r = p.getResult();
                    if (r instanceof String) p.setResult(patch((String) r));
                }
            });
            log("hook okhttp ResponseBody OK");
        } catch (Throwable t) {
            log("hook okhttp FAIL " + t);
        }
    }

    private void hookGson(ClassLoader cl) {
        try {
            Class<?> gson = XposedHelpers.findClass("com.google.gson.Gson", cl);
            XposedHelpers.findAndHookMethod(gson, "fromJson", String.class, Class.class,
                    new XC_MethodHook() {
                        @Override
                        protected void beforeHookedMethod(MethodHookParam p) {
                            if (p.args[0] instanceof String) p.args[0] = patch((String) p.args[0]);
                        }
                    });
            XposedHelpers.findAndHookMethod(gson, "fromJson", String.class,
                    java.lang.reflect.Type.class, new XC_MethodHook() {
                        @Override
                        protected void beforeHookedMethod(MethodHookParam p) {
                            if (p.args[0] instanceof String) p.args[0] = patch((String) p.args[0]);
                        }
                    });
            log("hook Gson OK");
        } catch (Throwable t) {
            log("hook Gson FAIL " + t);
        }
    }

    private void hookOrgJson(ClassLoader cl) {
        try {
            Class<?> jo = XposedHelpers.findClass("org.json.JSONObject", cl);
            XposedBridge.hookAllConstructors(jo, new XC_MethodHook() {
                @Override
                protected void beforeHookedMethod(MethodHookParam p) {
                    if (p.args != null && p.args.length == 1 && p.args[0] instanceof String) {
                        p.args[0] = patch((String) p.args[0]);
                    }
                }
            });
            log("hook org.json OK");
        } catch (Throwable t) {
            log("hook org.json FAIL " + t);
        }
    }
}

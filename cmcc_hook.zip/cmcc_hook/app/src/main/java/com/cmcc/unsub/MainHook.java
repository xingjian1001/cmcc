package com.cmcc.unsub;

import android.app.AndroidAppHelper;
import android.content.Context;
import android.os.Handler;
import android.os.Looper;
import android.widget.Toast;

import java.lang.reflect.Method;

import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;
import de.robv.android.xposed.callbacks.XC_LoadPackage;

/**
 * v7
 *
 * 1) cancelFlag "1" -> "0"：让「退订」按钮渲染出来（已证实有效）。
 * 2) 「和家庭分享费」额外注入一份 contractList，让它走另一条通道 ——
 *    合约退订（interfaceCode 20114 contractTdAuth / 20115 contractTd），
 *    该通道与「统一退订 20057」是两套后端服务，统一退订拒绝的拆包请求，
 *    合约退订未必拒。
 *
 * 依据（反混淆自 main_businessQuery + chunk-common）：
 *   合约退订请求体：
 *     {contractReturnEffTime, oprcode, contractId, contractInstanceId,
 *      codeType, productCode, spCode, bizCode, smsCode, ...}
 *   按钮显示条件：
 *     isCurrentMonth && contractId && contractInstanceId
 *     && ("01"===codeType && productCode) || ("02"===codeType && sPCode && bizCode)
 *     && "0"===contractFlag && !majorTag && "3"!==busiState
 *     && "0"===cancelFlag && "0"===cancelState
 *   所以注入时必须同时：
 *     contractFlag 1 -> 0，majorType 清空（!majorTag），cancelFlag 0，cancelState 0。
 */
public class MainHook implements IXposedHookLoadPackage {

    private static final String TAG = "CmccUnsub";
    private static final String PKG = "com.greenpoint.android.mc10086.activity";

    // 和家庭分享费
    private static final String CODE = "111002061806";
    private static final String INST = "30010967558403";
    private static final String NAME = "和家庭分享费";

    private static int rounds = 0;
    private static int injected = 0;

    @Override
    public void handleLoadPackage(XC_LoadPackage.LoadPackageParam lpparam) {
        if (!PKG.equals(lpparam.packageName)) return;
        XposedBridge.log(TAG + ": loaded");

        hookOkioBuffer(lpparam.classLoader);
        hookResponseBody(lpparam.classLoader);
        hookGson(lpparam.classLoader);
        hookOrgJson(lpparam.classLoader);

        toast("CmccUnsub v7 已注入");
    }

    private static String patch(String s) {
        if (s == null || s.isEmpty()) return s;
        if (!s.contains("cancelFlag")) return s;

        String out = s;

        // ① 注入合约退订信息（只针对和家庭分享费）
        if (out.contains(CODE)) {
            String t = injectContract(out);
            if (t != null && !t.equals(out)) {
                out = t;
                injected++;
                toast("已注入合约退订 #" + injected);
                XposedBridge.log(TAG + ": contract injected " + injected);
            }
        }

        // ② 放开 cancelFlag
        String out2 = out.replace("\"cancelFlag\":\"1\"", "\"cancelFlag\":\"0\"");
        if (!out2.equals(out)) {
            rounds++;
            XposedBridge.log(TAG + ": cancelFlag opened " + rounds);
        }
        return out2;
    }

    /**
     * 在 JSON 文本里定位 和家庭分享费 那个扁平对象，改四个字段并追加 contractList。
     * 数据是扁平对象（无嵌套），所以花括号扫描是安全的。
     */
    private static String injectContract(String s) {
        int k = s.indexOf("\"productCode\":\"" + CODE + "\"");
        if (k < 0) return s;

        int start = s.lastIndexOf('{', k);
        int end = s.indexOf('}', k);
        if (start < 0 || end < k) return s;

        String seg = s.substring(start, end + 1);
        if (seg.contains("\"contractId\"")) return s;      // 已经注入过

        String ns = seg;

        if (ns.contains("\"contractFlag\":\"1\"")) {
            ns = ns.replace("\"contractFlag\":\"1\"", "\"contractFlag\":\"0\"");
        } else if (!ns.contains("\"contractFlag\"")) {
            ns = ns.substring(0, ns.length() - 1) + ",\"contractFlag\":\"0\"}";
        }

        // !majorTag 才能显示合约退订按钮
        ns = ns.replace("\"majorType\":\"1\",", "\"majorType\":\"\",");
        ns = ns.replace("\"majorType\":\"1\"}", "\"majorType\":\"\"}");

        // cancelFlag / cancelState 都必须是 "0"
        ns = ns.replace("\"cancelFlag\":\"1\"", "\"cancelFlag\":\"0\"");
        ns = ns.replace("\"busiState\":\"3\"", "\"busiState\":\"4\"");

        if (ns.contains("\"cancelState\"")) {
            ns = ns.replace("\"cancelState\":\"1\"", "\"cancelState\":\"0\"");
        } else {
            ns = ns.substring(0, ns.length() - 1) + ",\"cancelState\":\"0\"}";
        }

        // 追加合约明细
        String contract = ",\"contractList\":{\"contractDetailsList\":[{"
                + "\"contractName\":\"" + NAME + "\","
                + "\"contractId\":\"" + CODE + "\","
                + "\"contractInstanceId\":\"" + INST + "\","
                + "\"cancelFlag\":\"0\","
                + "\"cancelState\":\"0\","
                + "\"contractReturnEffTime\":\"0\"}]}";

        ns = ns.substring(0, ns.length() - 1) + contract + "}";

        return s.substring(0, start) + ns + s.substring(end + 1);
    }

    private static void toast(final String msg) {
        try {
            new Handler(Looper.getMainLooper()).post(new Runnable() {
                @Override
                public void run() {
                    try {
                        Context ctx = AndroidAppHelper.currentApplication();
                        if (ctx != null) Toast.makeText(ctx, msg, Toast.LENGTH_SHORT).show();
                    } catch (Throwable ignored) {
                    }
                }
            });
        } catch (Throwable ignored) {
        }
    }

    private void hookOkioBuffer(ClassLoader cl) {
        try {
            Class<?> buf = XposedHelpers.findClass("okio.Buffer", cl);
            for (Method m : buf.getDeclaredMethods()) {
                if (!m.getName().equals("readUtf8") || m.getParameterTypes().length != 0) continue;
                XposedBridge.hookMethod(m, new XC_MethodHook() {
                    @Override
                    protected void afterHookedMethod(MethodHookParam p) {
                        Object r = p.getResult();
                        if (r instanceof String) p.setResult(patch((String) r));
                    }
                });
            }
            XposedHelpers.findAndHookMethod(buf, "readString", java.nio.charset.Charset.class,
                    new XC_MethodHook() {
                        @Override
                        protected void afterHookedMethod(MethodHookParam p) {
                            Object r = p.getResult();
                            if (r instanceof String) p.setResult(patch((String) r));
                        }
                    });
        } catch (Throwable t) {
            XposedBridge.log(TAG + ": okio fail " + t);
        }
    }

    private void hookResponseBody(ClassLoader cl) {
        try {
            Class<?> rb = XposedHelpers.findClass("okhttp3.ResponseBody", cl);
            XposedHelpers.findAndHookMethod(rb, "string", new XC_MethodHook() {
                @Override
                protected void afterHookedMethod(MethodHookParam p) {
                    Object r = p.getResult();
                    if (r instanceof String) p.setResult(patch((String) r));
                }
            });
        } catch (Throwable t) {
            XposedBridge.log(TAG + ": rb fail " + t);
        }
    }

    private void hookGson(ClassLoader cl) {
        try {
            Class<?> gson = XposedHelpers.findClass("com.google.gson.Gson", cl);
            XposedHelpers.findAndHookMethod(gson, "fromJson", String.class, Class.class,
                    new XC_MethodHook() {
                        @Override
                        protected void beforeHookedMethod(MethodHookParam p) {
                            if (p.args[0] instanceof String) p.args[0] = patch((String) p.args[0]);
                        }
                    });
            XposedHelpers.findAndHookMethod(gson, "fromJson", String.class,
                    java.lang.reflect.Type.class, new XC_MethodHook() {
                        @Override
                        protected void beforeHookedMethod(MethodHookParam p) {
                            if (p.args[0] instanceof String) p.args[0] = patch((String) p.args[0]);
                        }
                    });
        } catch (Throwable t) {
            XposedBridge.log(TAG + ": gson fail " + t);
        }
    }

    private void hookOrgJson(ClassLoader cl) {
        try {
            Class<?> jo = XposedHelpers.findClass("org.json.JSONObject", cl);
            XposedHelpers.findAndHookMethod(jo, "<init>", String.class, new XC_MethodHook() {
                @Override
                protected void beforeHookedMethod(MethodHookParam p) {
                    if (p.args[0] instanceof String) p.args[0] = patch((String) p.args[0]);
                }
            });
        } catch (Throwable t) {
            XposedBridge.log(TAG + ": json fail " + t);
        }
    }
}

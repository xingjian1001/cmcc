package com.cmcc.unsub;

import android.app.AndroidAppHelper;
import android.content.Context;
import android.os.Handler;
import android.os.Looper;
import android.webkit.ValueCallback;
import android.widget.Toast;

import java.io.File;
import java.io.FileOutputStream;
import java.lang.reflect.Method;
import java.text.SimpleDateFormat;
import java.util.Date;

import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;
import de.robv.android.xposed.callbacks.XC_LoadPackage;

/**
 * v10 —— 带日志。
 *
 * v8/v9 的 JS 注入都没让弹窗变化，但没法判断是「钩子没挂上」「页面不是 WebView」
 * 还是「JS 跑了但拿不到 Vuex」。这版把所有关键事件写进
 *   /data/data/com.greenpoint.android.mc10086.activity/files/cmcc_log.txt
 * 用 MT 管理器（root）取出来就能定位。
 */
public class MainHook implements IXposedHookLoadPackage {

    private static final String TAG = "CmccUnsub";
    private static final String PKG = "com.greenpoint.android.mc10086.activity";

    private static final String CODE = "111002061806";
    private static final String INST = "30010967558403";
    private static final String NAME = "和家庭分享费";

    private static int rounds = 0;
    private static int injected = 0;
    private static int urlSeq = 0;
    private static int jsSeq = 0;
    private static boolean x5Hooked = false;
    private static boolean nativeHooked = false;

    private static final String JS =
            "(function(){if(window.__CU9__)return;window.__CU9__=1;var n=0;"
          + "var t=setInterval(function(){n++;if(n>240){clearInterval(t);window.__CU8_SET='no-vue';return}"
          + "try{var el=document.getElementById('app');var vm=el&&el.__vue__;"
          + "if(!vm&&el&&el.__vue_app__){vm=el.__vue_app__._instance||el.__vue_app__}"
          + "var st=vm&&vm.$store&&vm.$store.state;if(!st||!st.remoteState)return;"
          + "var p=(st.userInfo&&st.userInfo.loginProvince)||'100';"
          + "var sc={zero_penalty_provinces:[p],phone_payment_provinces:[p],cash_payment_provinces:[p]};"
          + "st.remoteState.CMCC_BusinessQuery_ContractUnsubscribe_Scenario=JSON.stringify(sc);"
          + "window.__CU8_SET='ok-'+p;clearInterval(t)}catch(e){window.__CU8_SET='err-'+e}},500)})()";

    private static final String PING = "(window.__CU8_SET||'none')";

    @Override
    public void handleLoadPackage(XC_LoadPackage.LoadPackageParam lpparam) {
        if (!PKG.equals(lpparam.packageName)) return;

        log("=== loaded v10 pkg=" + lpparam.packageName + " process=" + lpparam.processName);

        hookOkioBuffer(lpparam.classLoader);
        hookResponseBody(lpparam.classLoader);
        hookGson(lpparam.classLoader);
        hookOrgJson(lpparam.classLoader);
        hookWebViewNative(lpparam.classLoader);
        startX5Watcher(lpparam.classLoader);
        hookAppCreate(lpparam.classLoader);

        toast("CmccUnsub v10 已注入");
    }

    /** Application 一旦创建就有 Context，把之前缓存的日志一次性落盘 */
    private void hookAppCreate(ClassLoader cl) {
        try {
            XposedHelpers.findAndHookMethod("android.app.Application", cl, "onCreate",
                    new XC_MethodHook() {
                        @Override
                        protected void afterHookedMethod(MethodHookParam p) {
                            log("Application.onCreate —— 日志开始落盘");
                        }
                    });
        } catch (Throwable t) {
            XposedBridge.log(TAG + ": appcreate fail " + t);
        }
    }

    // ---------------- 日志 ----------------

    private static File logFile() {
        try {
            Context c = AndroidAppHelper.currentApplication();
            if (c == null) return null;
            return new File(c.getFilesDir(), "cmcc_log.txt");
        } catch (Throwable t) {
            return null;
        }
    }

    private static final java.util.ArrayList<String> pending = new java.util.ArrayList<String>();

    private static void log(String msg) {
        String line = new SimpleDateFormat("HH:mm:ss").format(new Date()) + "  " + msg;
        XposedBridge.log(TAG + ": " + msg);
        try {
            File f = logFile();
            if (f == null) {
                synchronized (pending) {
                    if (pending.size() < 300) pending.add(line);
                }
                return;
            }
            if (f.length() > 300000) f.delete();
            FileOutputStream fo = new FileOutputStream(f, true);
            synchronized (pending) {
                for (String p : pending) fo.write((p + "\n").getBytes("UTF-8"));
                pending.clear();
            }
            fo.write((line + "\n").getBytes("UTF-8"));
            fo.close();
        } catch (Throwable ignored) {
        }
    }

    // ---------------- WebView ----------------

    private void hookWebViewNative(ClassLoader cl) {
        try {
            Class<?> wv = XposedHelpers.findClass("android.webkit.WebView", cl);
            XposedBridge.hookAllMethods(wv, "loadUrl", new PageHook("native"));
            XposedBridge.hookAllMethods(wv, "evaluateJavascript", new EvalHook("native"));
            nativeHooked = true;
            log("hook android.webkit.WebView OK");
        } catch (Throwable t) {
            log("hook android.webkit.WebView FAIL " + t);
        }
    }

    private void startX5Watcher(final ClassLoader cl) {
        Thread th = new Thread(new Runnable() {
            @Override
            public void run() {
                for (int i = 0; i < 240; i++) {
                    try {
                        Class<?> c = Class.forName("com.tencent.smtt.sdk.WebView", false, cl);
                        hookX5(c);
                        return;
                    } catch (Throwable ignored) {
                    }
                    try {
                        Thread.sleep(500);
                    } catch (Throwable ignored) {
                    }
                }
                log("X5 类 2 分钟内没出现");
            }
        });
        th.setDaemon(true);
        th.start();
    }

    private void hookX5(Class<?> c) {
        if (x5Hooked) return;
        x5Hooked = true;
        log("X5 类已加载: " + c.getName());
        try {
            XposedBridge.hookAllMethods(c, "loadUrl", new PageHook("x5"));
            XposedBridge.hookAllMethods(c, "evaluateJavascript", new EvalHook("x5"));
            log("hook X5 WebView OK");
            toast("X5 已挂钩");
        } catch (Throwable t) {
            log("hook X5 FAIL " + t);
        }
        try {
            Class<?> wc = Class.forName("com.tencent.smtt.sdk.WebViewClient", false, c.getClassLoader());
            XposedBridge.hookAllMethods(wc, "onPageFinished", new XC_MethodHook() {
                @Override
                protected void afterHookedMethod(MethodHookParam p) {
                    if (p.args == null || p.args.length < 2) return;
                    final Object w = p.args[0];
                    String url = String.valueOf(p.args[1]);
                    log("X5 onPageFinished " + cut(url));
                    if (w == null) return;
                    for (int i = 1; i <= 6; i++) {
                        new Handler(Looper.getMainLooper()).postDelayed(new Runnable() {
                            @Override
                            public void run() {
                                evalJs(w, JS, "onPageFinished");
                            }
                        }, 600L * i);
                    }
                    pingResult(w);
                }
            });
            log("hook X5 WebViewClient OK");
        } catch (Throwable t) {
            log("hook X5 WebViewClient FAIL " + t);
        }
    }

    private class PageHook extends XC_MethodHook {
        private final String tag;

        PageHook(String tag) {
            this.tag = tag;
        }

        @Override
        protected void afterHookedMethod(MethodHookParam p) {
            final Object w = p.thisObject;
            if (w == null) return;
            String u = "";
            if (p.args != null && p.args.length > 0 && p.args[0] instanceof String) {
                u = (String) p.args[0];
            }
            if (u.startsWith("javascript:")) return;
            if (urlSeq < 40) {
                urlSeq++;
                log("loadUrl[" + tag + "] " + w.getClass().getName() + " -> " + cut(u));
            }
            if (!(u.contains("10086") || u.contains("cmcc") || u.contains("businessQuery"))) return;
            for (int i = 1; i <= 8; i++) {
                new Handler(Looper.getMainLooper()).postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        evalJs(w, JS, "loadUrl");
                    }
                }, 1500L * i);
            }
            pingResult(w);
        }
    }

    private class EvalHook extends XC_MethodHook {
        private final String tag;

        EvalHook(String tag) {
            this.tag = tag;
        }

        @Override
        protected void beforeHookedMethod(MethodHookParam p) {
            if (p.args == null || p.args.length < 1) return;
            if (!(p.args[0] instanceof String)) return;
            String s = (String) p.args[0];
            if (jsSeq < 20) {
                jsSeq++;
                log("evaluateJavascript[" + tag + "] " + cut(s));
            }
            if (s.contains("__CU9__")) return;
            p.args[0] = s + ";" + JS;
        }
    }

    private static void evalJs(Object w, String js, String why) {
        if (w == null) return;
        try {
            Method m = w.getClass().getMethod("evaluateJavascript", String.class, ValueCallback.class);
            m.invoke(w, js, null);
            log("inject ok (" + why + ") via " + w.getClass().getName());
        } catch (Throwable t) {
            try {
                Method m = w.getClass().getMethod("loadUrl", String.class);
                m.invoke(w, "javascript:" + js);
                log("inject ok (" + why + ") via loadUrl javascript:");
            } catch (Throwable t2) {
                log("inject FAIL (" + why + ") " + t2);
            }
        }
    }

    private static void pingResult(final Object w) {
        new Handler(Looper.getMainLooper()).postDelayed(new Runnable() {
            @Override
            public void run() {
                try {
                    Method m = w.getClass().getMethod("evaluateJavascript", String.class, ValueCallback.class);
                    m.invoke(w, PING, new ValueCallback<String>() {
                        @Override
                        public void onReceiveValue(String v) {
                            log("PING result = " + v);
                            toast("注入结果 " + v);
                        }
                    });
                } catch (Throwable t) {
                    log("PING fail " + t);
                }
            }
        }, 12000L);
    }

    private static String cut(String s) {
        if (s == null) return "null";
        s = s.replace("\n", " ");
        return s.length() > 150 ? s.substring(0, 150) + "..." : s;
    }

    // ---------------- JSON ----------------

    private static String patch(String s) {
        if (s == null || s.isEmpty()) return s;
        if (!s.contains("cancelFlag")) return s;

        String out = s;

        if (out.contains(CODE)) {
            String t = injectContract(out);
            if (t != null && !t.equals(out)) {
                out = t;
                injected++;
                log("contract injected #" + injected);
                toast("已注入合约退订 #" + injected);
            }
        }

        String out2 = out.replace("\"cancelFlag\":\"1\"", "\"cancelFlag\":\"0\"");
        if (!out2.equals(out)) {
            rounds++;
            log("cancelFlag opened #" + rounds);
        }
        return out2;
    }

    private static String injectContract(String s) {
        int k = s.indexOf("\"productCode\":\"" + CODE + "\"");
        if (k < 0) return s;

        int start = s.lastIndexOf('{', k);
        int end = s.indexOf('}', k);
        if (start < 0 || end < k) return s;

        String seg = s.substring(start, end + 1);
        if (seg.contains("\"contractId\"")) return s;

        String ns = seg;

        if (ns.contains("\"contractFlag\":\"1\"")) {
            ns = ns.replace("\"contractFlag\":\"1\"", "\"contractFlag\":\"0\"");
        } else if (!ns.contains("\"contractFlag\"")) {
            ns = ns.substring(0, ns.length() - 1) + ",\"contractFlag\":\"0\"}";
        }

        ns = ns.replace("\"majorType\":\"1\",", "\"majorType\":\"\",");
        ns = ns.replace("\"majorType\":\"1\"}", "\"majorType\":\"\"}");
        ns = ns.replace("\"cancelFlag\":\"1\"", "\"cancelFlag\":\"0\"");
        ns = ns.replace("\"busiState\":\"3\"", "\"busiState\":\"4\"");

        if (ns.contains("\"cancelState\"")) {
            ns = ns.replace("\"cancelState\":\"1\"", "\"cancelState\":\"0\"");
        } else {
            ns = ns.substring(0, ns.length() - 1) + ",\"cancelState\":\"0\"}";
        }

        String contract = ",\"contractList\":{\"contractDetailsList\":[{"
                + "\"contractName\":\"" + NAME + "\","
                + "\"contractId\":\"" + CODE + "\","
                + "\"contractInstanceId\":\"" + INST + "\","
                + "\"cancelFlag\":\"0\","
                + "\"cancelState\":\"0\","
                + "\"contractReturnEffTime\":\"0\"}]}";

        ns = ns.substring(0, ns.length() - 1) + contract + "}";

        return s.substring(0, start) + ns + s.substring(end + 1);
    }

    private static void toast(final String msg) {
        try {
            new Handler(Looper.getMainLooper()).post(new Runnable() {
                @Override
                public void run() {
                    try {
                        Context ctx = AndroidAppHelper.currentApplication();
                        if (ctx != null) Toast.makeText(ctx, msg, Toast.LENGTH_SHORT).show();
                    } catch (Throwable ignored) {
                    }
                }
            });
        } catch (Throwable ignored) {
        }
    }

    // ---------------- 网络层 ----------------

    private void hookOkioBuffer(ClassLoader cl) {
        try {
            Class<?> buf = XposedHelpers.findClass("okio.Buffer", cl);
            int n = 0;
            for (Method m : buf.getDeclaredMethods()) {
                if (!m.getName().equals("readUtf8") || m.getParameterTypes().length != 0) continue;
                XposedBridge.hookMethod(m, new XC_MethodHook() {
                    @Override
                    protected void afterHookedMethod(MethodHookParam p) {
                        Object r = p.getResult();
                        if (r instanceof String) p.setResult(patch((String) r));
                    }
                });
                n++;
            }
            XposedHelpers.findAndHookMethod(buf, "readString", java.nio.charset.Charset.class,
                    new XC_MethodHook() {
                        @Override
                        protected void afterHookedMethod(MethodHookParam p) {
                            Object r = p.getResult();
                            if (r instanceof String) p.setResult(patch((String) r));
                        }
                    });
            log("hook okio.Buffer readUtf8 x" + n);
        } catch (Throwable t) {
            log("hook okio FAIL " + t);
        }
    }

    private void hookResponseBody(ClassLoader cl) {
        try {
            Class<?> rb = XposedHelpers.findClass("okhttp3.ResponseBody", cl);
            XposedHelpers.findAndHookMethod(rb, "string", new XC_MethodHook() {
                @Override
                protected void afterHookedMethod(MethodHookParam p) {
                    Object r = p.getResult();
                    if (r instanceof String) p.setResult(patch((String) r));
                }
            });
            log("hook okhttp ResponseBody OK");
        } catch (Throwable t) {
            log("hook okhttp FAIL " + t);
        }
    }

    private void hookGson(ClassLoader cl) {
        try {
            Class<?> gson = XposedHelpers.findClass("com.google.gson.Gson", cl);
            XposedHelpers.findAndHookMethod(gson, "fromJson", String.class, Class.class,
                    new XC_MethodHook() {
                        @Override
                        protected void beforeHookedMethod(MethodHookParam p) {
                            if (p.args[0] instanceof String) p.args[0] = patch((String) p.args[0]);
                        }
                    });
            XposedHelpers.findAndHookMethod(gson, "fromJson", String.class,
                    java.lang.reflect.Type.class, new XC_MethodHook() {
                        @Override
                        protected void beforeHookedMethod(MethodHookParam p) {
                            if (p.args[0] instanceof String) p.args[0] = patch((String) p.args[0]);
                        }
                    });
            log("hook Gson OK");
        } catch (Throwable t) {
            log("hook Gson FAIL " + t);
        }
    }

    private void hookOrgJson(ClassLoader cl) {
        try {
            Class<?> jo = XposedHelpers.findClass("org.json.JSONObject", cl);
            XposedHelpers.findAndHookMethod(jo, "<init>", String.class, new XC_MethodHook() {
                @Override
                protected void beforeHookedMethod(MethodHookParam p) {
                    if (p.args[0] instanceof String) p.args[0] = patch((String) p.args[0]);
                }
            });
            log("hook org.json OK");
        } catch (Throwable t) {
            log("hook org.json FAIL " + t);
        }
    }
}

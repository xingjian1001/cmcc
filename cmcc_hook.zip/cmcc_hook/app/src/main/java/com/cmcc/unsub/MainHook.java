package com.cmcc.unsub;

import android.app.AndroidAppHelper;
import android.content.Context;
import android.os.Handler;
import android.os.Looper;
import android.webkit.ValueCallback;
import android.widget.Toast;

import java.lang.reflect.Method;

import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;
import de.robv.android.xposed.callbacks.XC_LoadPackage;

/**
 * v9
 *
 * v8 的 WebView 注入没生效：App 用的是腾讯 X5 内核
 * （APK 里有 libx5linker.so，运行时类名 com.tencent.smtt.sdk.WebView，
 *  它不继承 android.webkit.WebView，所以挂在 android.webkit.WebView 上的钩子一次都没触发）。
 *
 * v9 三件事：
 *  1) 轮询等 X5 类被加载，然后挂 X5 的 loadUrl / evaluateJavascript / onPageFinished
 *  2) 注入 JS：把当前省份写进 CMCC_BusinessQuery_ContractUnsubscribe_Scenario 白名单，
 *     让 checkUnsubscribeState 不再直接返回 {type:"service"}
 *  3) 注入后回读 window.__CU8_SET，用 Toast 告诉我们到底成没成
 */
public class MainHook implements IXposedHookLoadPackage {

    private static final String TAG = "CmccUnsub";
    private static final String PKG = "com.greenpoint.android.mc10086.activity";

    private static final String CODE = "111002061806";   // 和家庭分享费
    private static final String INST = "30010967558403"; // 实例 ID
    private static final String NAME = "和家庭分享费";

    private static int rounds = 0;
    private static int injected = 0;
    private static boolean x5Hooked = false;

    /** 注入的 JS：单行、只用单引号，避免被 "javascript:" URL 截断 */
    private static final String JS =
            "(function(){if(window.__CU9__)return;window.__CU9__=1;var n=0;"
          + "var t=setInterval(function(){n++;if(n>240){clearInterval(t);window.__CU8_SET='no-vue';return}"
          + "try{var el=document.getElementById('app');var vm=el&&el.__vue__;"
          + "var st=vm&&vm.$store&&vm.$store.state;if(!st||!st.remoteState)return;"
          + "var p=(st.userInfo&&st.userInfo.loginProvince)||'100';"
          + "var sc={zero_penalty_provinces:[p],phone_payment_provinces:[p],cash_payment_provinces:[p]};"
          + "st.remoteState.CMCC_BusinessQuery_ContractUnsubscribe_Scenario=JSON.stringify(sc);"
          + "window.__CU8_SET='ok-'+p;clearInterval(t)}catch(e){window.__CU8_SET='err-'+e}},500)})()";

    private static final String PING = "(window.__CU8_SET||'none')";

    @Override
    public void handleLoadPackage(XC_LoadPackage.LoadPackageParam lpparam) {
        if (!PKG.equals(lpparam.packageName)) return;
        XposedBridge.log(TAG + ": loaded");

        hookOkioBuffer(lpparam.classLoader);
        hookResponseBody(lpparam.classLoader);
        hookGson(lpparam.classLoader);
        hookOrgJson(lpparam.classLoader);

        hookWebViewNative(lpparam.classLoader);
        startX5Watcher(lpparam.classLoader);

        toast("CmccUnsub v9 已注入");
    }

    // ---------------- WebView ----------------

    /** android.webkit.WebView（系统内核，兜底） */
    private void hookWebViewNative(ClassLoader cl) {
        try {
            Class<?> wv = XposedHelpers.findClass("android.webkit.WebView", cl);
            XposedBridge.hookAllMethods(wv, "loadUrl", new PageHook());
            XposedBridge.hookAllMethods(wv, "evaluateJavascript", new EvalHook());
        } catch (Throwable t) {
            XposedBridge.log(TAG + ": webview native fail " + t);
        }
    }

    /** X5 是运行时动态加载的，只能轮询等它出现 */
    private void startX5Watcher(final ClassLoader cl) {
        Thread th = new Thread(new Runnable() {
            @Override
            public void run() {
                for (int i = 0; i < 240; i++) {
                    try {
                        Class<?> c = Class.forName("com.tencent.smtt.sdk.WebView", false, cl);
                        hookX5(c);
                        return;
                    } catch (Throwable ignored) {
                    }
                    try {
                        Thread.sleep(500);
                    } catch (Throwable ignored) {
                    }
                }
            }
        });
        th.setDaemon(true);
        th.start();
    }

    private void hookX5(Class<?> c) {
        if (x5Hooked) return;
        x5Hooked = true;
        try {
            XposedBridge.hookAllMethods(c, "loadUrl", new PageHook());
            XposedBridge.hookAllMethods(c, "evaluateJavascript", new EvalHook());
            XposedBridge.log(TAG + ": X5 hooked");
            toast("X5 内核已挂钩");
        } catch (Throwable t) {
            XposedBridge.log(TAG + ": x5 fail " + t);
        }
        try {
            Class<?> wc = Class.forName("com.tencent.smtt.sdk.WebViewClient", false, c.getClassLoader());
            XposedBridge.hookAllMethods(wc, "onPageFinished", new XC_MethodHook() {
                @Override
                protected void afterHookedMethod(MethodHookParam p) {
                    if (p.args == null || p.args.length < 1) return;
                    final Object w = p.args[0];
                    if (w == null) return;
                    toast("页面加载完成，开始注入");
                    for (int i = 1; i <= 6; i++) {
                        new Handler(Looper.getMainLooper()).postDelayed(new Runnable() {
                            @Override
                            public void run() {
                                evalJs(w, JS);
                            }
                        }, 600L * i);
                    }
                    pingResult(w);
                }
            });
        } catch (Throwable t) {
            XposedBridge.log(TAG + ": x5 client fail " + t);
        }
    }

    private class PageHook extends XC_MethodHook {
        @Override
        protected void afterHookedMethod(MethodHookParam p) {
            final Object w = p.thisObject;
            if (w == null) return;
            String u = "";
            if (p.args != null && p.args.length > 0 && p.args[0] instanceof String) {
                u = (String) p.args[0];
            }
            if (u.startsWith("javascript:")) return;
            for (int i = 1; i <= 8; i++) {
                new Handler(Looper.getMainLooper()).postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        evalJs(w, JS);
                    }
                }, 1500L * i);
            }
        }
    }

    /** App 自己调 evaluateJavascript 时，把我们的脚本接在它后面 —— 最稳的搭车点 */
    private class EvalHook extends XC_MethodHook {
        @Override
        protected void beforeHookedMethod(MethodHookParam p) {
            if (p.args == null || p.args.length < 1) return;
            if (!(p.args[0] instanceof String)) return;
            String s = (String) p.args[0];
            if (s.contains("__CU9__")) return;
            p.args[0] = s + ";" + JS;
        }
    }

    private static void evalJs(Object w, String js) {
        if (w == null) return;
        try {
            Method m = w.getClass().getMethod("evaluateJavascript", String.class, ValueCallback.class);
            m.invoke(w, js, null);
        } catch (Throwable t) {
            try {
                Method m = w.getClass().getMethod("loadUrl", String.class);
                m.invoke(w, "javascript:" + js);
            } catch (Throwable t2) {
            }
        }
    }

    /** 12 秒后回读注入结果，用 Toast 报出来 */
    private static void pingResult(final Object w) {
        new Handler(Looper.getMainLooper()).postDelayed(new Runnable() {
            @Override
            public void run() {
                try {
                    Method m = w.getClass().getMethod("evaluateJavascript", String.class, ValueCallback.class);
                    m.invoke(w, PING, new ValueCallback<String>() {
                        @Override
                        public void onReceiveValue(String v) {
                            toast("注入结果 " + v);
                        }
                    });
                } catch (Throwable ignored) {
                }
            }
        }, 12000L);
    }

    // ---------------- JSON 改写 ----------------

    private static String patch(String s) {
        if (s == null || s.isEmpty()) return s;
        if (!s.contains("cancelFlag")) return s;

        String out = s;

        if (out.contains(CODE)) {
            String t = injectContract(out);
            if (t != null && !t.equals(out)) {
                out = t;
                injected++;
                toast("已注入合约退订 #" + injected);
                XposedBridge.log(TAG + ": contract injected " + injected);
            }
        }

        String out2 = out.replace("\"cancelFlag\":\"1\"", "\"cancelFlag\":\"0\"");
        if (!out2.equals(out)) {
            rounds++;
            XposedBridge.log(TAG + ": cancelFlag opened " + rounds);
        }
        return out2;
    }

    private static String injectContract(String s) {
        int k = s.indexOf("\"productCode\":\"" + CODE + "\"");
        if (k < 0) return s;

        int start = s.lastIndexOf('{', k);
        int end = s.indexOf('}', k);
        if (start < 0 || end < k) return s;

        String seg = s.substring(start, end + 1);
        if (seg.contains("\"contractId\"")) return s;

        String ns = seg;

        if (ns.contains("\"contractFlag\":\"1\"")) {
            ns = ns.replace("\"contractFlag\":\"1\"", "\"contractFlag\":\"0\"");
        } else if (!ns.contains("\"contractFlag\"")) {
            ns = ns.substring(0, ns.length() - 1) + ",\"contractFlag\":\"0\"}";
        }

        ns = ns.replace("\"majorType\":\"1\",", "\"majorType\":\"\",");
        ns = ns.replace("\"majorType\":\"1\"}", "\"majorType\":\"\"}");
        ns = ns.replace("\"cancelFlag\":\"1\"", "\"cancelFlag\":\"0\"");
        ns = ns.replace("\"busiState\":\"3\"", "\"busiState\":\"4\"");

        if (ns.contains("\"cancelState\"")) {
            ns = ns.replace("\"cancelState\":\"1\"", "\"cancelState\":\"0\"");
        } else {
            ns = ns.substring(0, ns.length() - 1) + ",\"cancelState\":\"0\"}";
        }

        String contract = ",\"contractList\":{\"contractDetailsList\":[{"
                + "\"contractName\":\"" + NAME + "\","
                + "\"contractId\":\"" + CODE + "\","
                + "\"contractInstanceId\":\"" + INST + "\","
                + "\"cancelFlag\":\"0\","
                + "\"cancelState\":\"0\","
                + "\"contractReturnEffTime\":\"0\"}]}";

        ns = ns.substring(0, ns.length() - 1) + contract + "}";

        return s.substring(0, start) + ns + s.substring(end + 1);
    }

    private static void toast(final String msg) {
        try {
            new Handler(Looper.getMainLooper()).post(new Runnable() {
                @Override
                public void run() {
                    try {
                        Context ctx = AndroidAppHelper.currentApplication();
                        if (ctx != null) Toast.makeText(ctx, msg, Toast.LENGTH_SHORT).show();
                    } catch (Throwable ignored) {
                    }
                }
            });
        } catch (Throwable ignored) {
        }
    }

    // ---------------- 网络层钩子 ----------------

    private void hookOkioBuffer(ClassLoader cl) {
        try {
            Class<?> buf = XposedHelpers.findClass("okio.Buffer", cl);
            for (Method m : buf.getDeclaredMethods()) {
                if (!m.getName().equals("readUtf8") || m.getParameterTypes().length != 0) continue;
                XposedBridge.hookMethod(m, new XC_MethodHook() {
                    @Override
                    protected void afterHookedMethod(MethodHookParam p) {
                        Object r = p.getResult();
                        if (r instanceof String) p.setResult(patch((String) r));
                    }
                });
            }
            XposedHelpers.findAndHookMethod(buf, "readString", java.nio.charset.Charset.class,
                    new XC_MethodHook() {
                        @Override
                        protected void afterHookedMethod(MethodHookParam p) {
                            Object r = p.getResult();
                            if (r instanceof String) p.setResult(patch((String) r));
                        }
                    });
        } catch (Throwable t) {
            XposedBridge.log(TAG + ": okio fail " + t);
        }
    }

    private void hookResponseBody(ClassLoader cl) {
        try {
            Class<?> rb = XposedHelpers.findClass("okhttp3.ResponseBody", cl);
            XposedHelpers.findAndHookMethod(rb, "string", new XC_MethodHook() {
                @Override
                protected void afterHookedMethod(MethodHookParam p) {
                    Object r = p.getResult();
                    if (r instanceof String) p.setResult(patch((String) r));
                }
            });
        } catch (Throwable t) {
            XposedBridge.log(TAG + ": rb fail " + t);
        }
    }

    private void hookGson(ClassLoader cl) {
        try {
            Class<?> gson = XposedHelpers.findClass("com.google.gson.Gson", cl);
            XposedHelpers.findAndHookMethod(gson, "fromJson", String.class, Class.class,
                    new XC_MethodHook() {
                        @Override
                        protected void beforeHookedMethod(MethodHookParam p) {
                            if (p.args[0] instanceof String) p.args[0] = patch((String) p.args[0]);
                        }
                    });
            XposedHelpers.findAndHookMethod(gson, "fromJson", String.class,
                    java.lang.reflect.Type.class, new XC_MethodHook() {
                        @Override
                        protected void beforeHookedMethod(MethodHookParam p) {
                            if (p.args[0] instanceof String) p.args[0] = patch((String) p.args[0]);
                        }
                    });
        } catch (Throwable t) {
            XposedBridge.log(TAG + ": gson fail " + t);
        }
    }

    private void hookOrgJson(ClassLoader cl) {
        try {
            Class<?> jo = XposedHelpers.findClass("org.json.JSONObject", cl);
            XposedHelpers.findAndHookMethod(jo, "<init>", String.class, new XC_MethodHook() {
                @Override
                protected void beforeHookedMethod(MethodHookParam p) {
                    if (p.args[0] instanceof String) p.args[0] = patch((String) p.args[0]);
                }
            });
        } catch (Throwable t) {
            XposedBridge.log(TAG + ": json fail " + t);
        }
    }
}

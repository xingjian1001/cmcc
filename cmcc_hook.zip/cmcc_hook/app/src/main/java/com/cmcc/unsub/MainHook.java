package com.cmcc.unsub;

import android.app.AndroidAppHelper;
import android.content.Context;
import android.os.Handler;
import android.os.Looper;
import android.widget.Toast;

import java.io.File;
import java.io.FileOutputStream;
import java.lang.reflect.Method;

import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;
import de.robv.android.xposed.callbacks.XC_LoadPackage;

/**
 * v4
 * 依据真实抓包数据：cancelFlag="0" 才有退订按钮，"1" 就没有。
 * 其余字段（busiState、unsubscribeFlag、contractFlag）全部无区分度，一律不动。
 */
public class MainHook implements IXposedHookLoadPackage {

    private static final String TAG = "CmccUnsub";
    private static final String PKG = "com.greenpoint.android.mc10086.activity";

    private static int rounds = 0;
    private static int reqSeq = 0;

    @Override
    public void handleLoadPackage(XC_LoadPackage.LoadPackageParam lpparam) {
        if (!PKG.equals(lpparam.packageName)) return;
        XposedBridge.log(TAG + ": loaded");

        hookOkioBuffer(lpparam.classLoader);
        hookResponseBody(lpparam.classLoader);
        hookGson(lpparam.classLoader);
        hookOrgJson(lpparam.classLoader);

        toast("CmccUnsub v5 已注入");
    }

    private static String patch(String s) {
        if (s == null || s.isEmpty()) return s;

        // 请求体：含 productCode/instanceId 但不含 busiState → 是要发出去的参数，落盘
        if (s.contains("productCode") && s.contains("instanceId") && !s.contains("busiState")) {
            if (reqSeq < 6) {
                reqSeq++;
                String p = dumpTo(s, "cmcc_req_" + reqSeq + ".json");
                toast("请求参数已存 " + p);
            }
            return s;
        }

        if (!s.contains("cancelFlag")) return s;

        String out = s.replace("\"cancelFlag\":\"1\"", "\"cancelFlag\":\"0\"");

        if (!out.equals(s)) {
            rounds++;
            toast("cancelFlag 已放开 #" + rounds);
            XposedBridge.log(TAG + ": patched " + rounds);
        }
        return out;
    }

    private static String dumpTo(String s, String name) {
        try {
            Context ctx = AndroidAppHelper.currentApplication();
            if (ctx == null) return "(no ctx)";
            File f = new File(ctx.getFilesDir(), name);
            FileOutputStream fo = new FileOutputStream(f);
            fo.write(s.getBytes("UTF-8"));
            fo.close();
            return f.getAbsolutePath();
        } catch (Throwable t) {
            return "(fail)";
        }
    }

    private static void toast(final String msg) {
        try {
            new Handler(Looper.getMainLooper()).post(new Runnable() {
                @Override
                public void run() {
                    try {
                        Context ctx = AndroidAppHelper.currentApplication();
                        if (ctx != null) Toast.makeText(ctx, msg, Toast.LENGTH_SHORT).show();
                    } catch (Throwable ignored) {
                    }
                }
            });
        } catch (Throwable ignored) {
        }
    }

    private void hookOkioBuffer(ClassLoader cl) {
        try {
            Class<?> buf = XposedHelpers.findClass("okio.Buffer", cl);
            for (Method m : buf.getDeclaredMethods()) {
                if (!m.getName().equals("readUtf8") || m.getParameterTypes().length != 0) continue;
                XposedBridge.hookMethod(m, new XC_MethodHook() {
                    @Override
                    protected void afterHookedMethod(MethodHookParam p) {
                        Object r = p.getResult();
                        if (r instanceof String) p.setResult(patch((String) r));
                    }
                });
            }
            XposedHelpers.findAndHookMethod(buf, "writeUtf8", String.class, new XC_MethodHook() {
                @Override
                protected void beforeHookedMethod(MethodHookParam p) {
                    if (p.args[0] instanceof String) {
                        Object a = p.args[0];
                        p.args[0] = patch((String) a);
                    }
                }
            });
            XposedHelpers.findAndHookMethod(buf, "readString", java.nio.charset.Charset.class,
                    new XC_MethodHook() {
                        @Override
                        protected void afterHookedMethod(MethodHookParam p) {
                            Object r = p.getResult();
                            if (r instanceof String) p.setResult(patch((String) r));
                        }
                    });
        } catch (Throwable t) {
            XposedBridge.log(TAG + ": okio fail " + t);
        }
    }

    private void hookResponseBody(ClassLoader cl) {
        try {
            Class<?> rb = XposedHelpers.findClass("okhttp3.ResponseBody", cl);
            XposedHelpers.findAndHookMethod(rb, "string", new XC_MethodHook() {
                @Override
                protected void afterHookedMethod(MethodHookParam p) {
                    Object r = p.getResult();
                    if (r instanceof String) p.setResult(patch((String) r));
                }
            });
        } catch (Throwable t) {
            XposedBridge.log(TAG + ": rb fail " + t);
        }
    }

    private void hookGson(ClassLoader cl) {
        try {
            Class<?> gson = XposedHelpers.findClass("com.google.gson.Gson", cl);
            XposedHelpers.findAndHookMethod(gson, "fromJson", String.class, Class.class,
                    new XC_MethodHook() {
                        @Override
                        protected void beforeHookedMethod(MethodHookParam p) {
                            if (p.args[0] instanceof String) p.args[0] = patch((String) p.args[0]);
                        }
                    });
            XposedHelpers.findAndHookMethod(gson, "fromJson", String.class,
                    java.lang.reflect.Type.class, new XC_MethodHook() {
                        @Override
                        protected void beforeHookedMethod(MethodHookParam p) {
                            if (p.args[0] instanceof String) p.args[0] = patch((String) p.args[0]);
                        }
                    });
        } catch (Throwable t) {
            XposedBridge.log(TAG + ": gson fail " + t);
        }
    }

    private void hookOrgJson(ClassLoader cl) {
        try {
            Class<?> jo = XposedHelpers.findClass("org.json.JSONObject", cl);
            XposedHelpers.findAndHookMethod(jo, "<init>", String.class, new XC_MethodHook() {
                @Override
                protected void beforeHookedMethod(MethodHookParam p) {
                    if (p.args[0] instanceof String) p.args[0] = patch((String) p.args[0]);
                }
            });
        } catch (Throwable t) {
            XposedBridge.log(TAG + ": json fail " + t);
        }
    }
}

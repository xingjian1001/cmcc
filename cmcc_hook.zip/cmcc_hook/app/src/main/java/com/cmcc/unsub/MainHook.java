package com.cmcc.unsub;

import android.app.AndroidAppHelper;
import android.content.Context;
import android.os.Handler;
import android.os.Looper;
import android.widget.Toast;

import java.lang.reflect.Method;

import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;
import de.robv.android.xposed.callbacks.XC_LoadPackage;

/**
 * 把业务列表 JSON 里的 unsubscribeFlag 从 0 改成 1，让「退订」按钮出现。
 * 日志页不可用时靠 Toast 反馈，不需要看 LSPosed 日志。
 */
public class MainHook implements IXposedHookLoadPackage {

    private static final String TAG = "CmccUnsub";
    private static final String PKG = "com.greenpoint.android.mc10086.activity";
    private static final String FIELD = "unsubscribeFlag";

    private static int hits = 0;
    private static boolean sawBusiState = false;
    private static boolean toastedInject = false;

    @Override
    public void handleLoadPackage(XC_LoadPackage.LoadPackageParam lpparam) {
        if (!PKG.equals(lpparam.packageName)) return;

        XposedBridge.log(TAG + ": loaded into " + lpparam.packageName);

        hookOkioBuffer(lpparam.classLoader);
        hookResponseBody(lpparam.classLoader);
        hookGson(lpparam.classLoader);
        hookOrgJson(lpparam.classLoader);

        toast("CmccUnsub 已注入");
    }

    // ---------- 替换逻辑 ----------
    private static String patch(String s) {
        if (s == null || s.isEmpty()) return s;

        if (!sawBusiState && s.contains("busiState")) {
            sawBusiState = true;
            toast("见到业务列表 len=" + s.length());
        }

        if (!s.contains(FIELD)) return s;

        String out = s
                .replace("\"unsubscribeFlag\":\"0\"", "\"unsubscribeFlag\":\"1\"")
                .replace("\"unsubscribeFlag\": \"0\"", "\"unsubscribeFlag\":\"1\"")
                .replace("\"unsubscribeFlag\":0", "\"unsubscribeFlag\":\"1\"")
                .replace("\"unsubscribeFlag\":false", "\"unsubscribeFlag\":\"1\"");

        if (!out.equals(s)) {
            hits++;
            toast("已改写 #" + hits);
            XposedBridge.log(TAG + ": patched #" + hits + " len=" + s.length());
        } else {
            int i = s.indexOf(FIELD);
            String frag = s.substring(Math.max(0, i - 60), Math.min(s.length(), i + 90));
            toast("格式不同: " + frag);
            XposedBridge.log(TAG + ": no-match frag=" + frag);
        }
        return out;
    }

    // ---------- Toast ----------
    private static void toast(final String msg) {
        try {
            new Handler(Looper.getMainLooper()).post(new Runnable() {
                @Override
                public void run() {
                    try {
                        Context ctx = AndroidAppHelper.currentApplication();
                        if (ctx == null) return;
                        Toast.makeText(ctx, msg, Toast.LENGTH_LONG).show();
                    } catch (Throwable ignored) {
                    }
                }
            });
        } catch (Throwable ignored) {
        }
    }

    // ---------- 1) okio.Buffer ----------
    private void hookOkioBuffer(ClassLoader cl) {
        try {
            Class<?> buf = XposedHelpers.findClass("okio.Buffer", cl);
            for (Method m : buf.getDeclaredMethods()) {
                if (!m.getName().equals("readUtf8")) continue;
                if (m.getParameterTypes().length != 0) continue;
                XposedBridge.hookMethod(m, new XC_MethodHook() {
                    @Override
                    protected void afterHookedMethod(MethodHookParam p) {
                        Object r = p.getResult();
                        if (r instanceof String) p.setResult(patch((String) r));
                    }
                });
            }
            XposedHelpers.findAndHookMethod(buf, "readString", java.nio.charset.Charset.class,
                    new XC_MethodHook() {
                        @Override
                        protected void afterHookedMethod(MethodHookParam p) {
                            Object r = p.getResult();
                            if (r instanceof String) p.setResult(patch((String) r));
                        }
                    });
        } catch (Throwable t) {
            XposedBridge.log(TAG + ": okio fail " + t);
        }
    }

    // ---------- 2) okhttp3.ResponseBody.string() ----------
    private void hookResponseBody(ClassLoader cl) {
        try {
            Class<?> rb = XposedHelpers.findClass("okhttp3.ResponseBody", cl);
            XposedHelpers.findAndHookMethod(rb, "string", new XC_MethodHook() {
                @Override
                protected void afterHookedMethod(MethodHookParam p) {
                    Object r = p.getResult();
                    if (r instanceof String) p.setResult(patch((String) r));
                }
            });
        } catch (Throwable t) {
            XposedBridge.log(TAG + ": ResponseBody fail " + t);
        }
    }

    // ---------- 3) Gson ----------
    private void hookGson(ClassLoader cl) {
        try {
            Class<?> gson = XposedHelpers.findClass("com.google.gson.Gson", cl);
            XposedHelpers.findAndHookMethod(gson, "fromJson", String.class, Class.class,
                    new XC_MethodHook() {
                        @Override
                        protected void beforeHookedMethod(MethodHookParam p) {
                            if (p.args[0] instanceof String) p.args[0] = patch((String) p.args[0]);
                        }
                    });
            XposedHelpers.findAndHookMethod(gson, "fromJson", String.class,
                    java.lang.reflect.Type.class, new XC_MethodHook() {
                        @Override
                        protected void beforeHookedMethod(MethodHookParam p) {
                            if (p.args[0] instanceof String) p.args[0] = patch((String) p.args[0]);
                        }
                    });
        } catch (Throwable t) {
            XposedBridge.log(TAG + ": Gson fail " + t);
        }
    }

    // ---------- 4) org.json ----------
    private void hookOrgJson(ClassLoader cl) {
        try {
            Class<?> jo = XposedHelpers.findClass("org.json.JSONObject", cl);
            XposedHelpers.findAndHookMethod(jo, "<init>", String.class, new XC_MethodHook() {
                @Override
                protected void beforeHookedMethod(MethodHookParam p) {
                    if (p.args[0] instanceof String) p.args[0] = patch((String) p.args[0]);
                }
            });
        } catch (Throwable t) {
            XposedBridge.log(TAG + ": org.json fail " + t);
        }
    }
}
